//
//  CityModel.swift
//  MakeDropDown
//
//  Created by ems on 02/05/19.
//  Copyright © 2019 Majesco. All rights reserved.
//

import Foundation
struct CityModel {
    var cityName: String
    var countryName: String
}
